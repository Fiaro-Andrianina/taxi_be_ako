import { useMemo, useEffect, useState } from 'react';
import { getPositionsKey } from '../utils/geo';
import { fetchRoadRoutePositions } from '../utils/api';

export function useRoadRoutePositions(basePositions, shouldRoute = true) {
  const positionsKey = useMemo(() => getPositionsKey(basePositions), [basePositions]);
  const [roadPositions, setRoadPositions] = useState(basePositions);

  useEffect(() => {
    if (!shouldRoute || basePositions.length < 2) {
      setRoadPositions(basePositions);
      return undefined;
    }

    const controller = new AbortController();
    setRoadPositions(basePositions);

    fetchRoadRoutePositions(basePositions, controller.signal)
      .then((positions) => setRoadPositions(positions))
      .catch((error) => {
        if (error.name !== 'AbortError') {
          setRoadPositions(basePositions);
        }
      });

    return () => controller.abort();
  }, [positionsKey, basePositions, shouldRoute]);

  return roadPositions;
}
