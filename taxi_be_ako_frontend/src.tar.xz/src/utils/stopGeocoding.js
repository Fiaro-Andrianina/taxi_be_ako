/**
 * Correction des coordonnées d'arrêt selon le nom de quartier (Antananarivo).
 * Miroir client de transport/services/stop_geocoding.py
 */

const TANA_QUARTIERS = {
  '67 ha': [-18.901158, 47.509165],
  '67ha': [-18.901158, 47.509165],
  analakely: [-18.904096, 47.521574],
  anosy: [-18.91982, 47.520117],
  mahamasina: [-18.91894, 47.524224],
  ivandry: [-18.86923, 47.528121],
  ankorondrano: [-18.889419, 47.522541],
  ambohijatovo: [-18.91004, 47.52856],
  ambanidia: [-18.919377, 47.538257],
  tanjombato: [-18.954453, 47.529021],
  amboditsiry: [-18.886345, 47.539482],
  antanimena: [-18.896965, 47.521152],
  andohananalakely: [-18.904096, 47.521574],
  ampandrana: [-18.8802, 47.5318],
  ampefiloha: [-18.9145, 47.5268],
  ambodivona: [-18.9068, 47.5245],
  ambohimanarina: [-18.8605, 47.4785],
  andoharanofotsy: [-18.8955, 47.5485],
  andravoahangy: [-18.898577, 47.530833],
  ankadifotsy: [-18.9255, 47.5125],
  ankatso: [-18.9125, 47.5355],
  antohomadinika: [-18.9142, 47.5318],
  besarety: [-18.9025, 47.5195],
  faravohitra: [-18.9055, 47.5355],
  isoraka: [-18.913, 47.528],
  isotry: [-18.9196, 47.5178],
  itaosy: [-18.924, 47.5072],
  andavamamba: [-18.92, 47.5182],
  soanierana: [-18.9322, 47.54],
  tsimbazaza: [-18.9318, 47.5258],
  rova: [-18.9088, 47.534],
  vasakosy: [-18.9195, 47.5105],
  morondava: [-18.921, 47.5055],
  fasankarana: [-18.946154, 47.516431],
  ambodimita: [-18.865569, 47.486222],
  ambohidroa: [-18.9075, 47.5378],
  mausolee: [-18.91167, 47.54667],
  ampasapito: [-18.896627, 47.545835],
  antanetibe: [-18.83399, 47.464285],
};

const BBOX = { south: -19.05, west: 47.45, north: -18.8, east: 47.6 };

function norm(name) {
  return String(name || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[''`]/g, ' ')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function distM(a, b) {
  const dlat = a[0] - b[0];
  const dlng = a[1] - b[1];
  return Math.hypot(dlat, dlng) * 111000;
}

function inBbox(lat, lng) {
  return lat >= BBOX.south && lat <= BBOX.north && lng >= BBOX.west && lng <= BBOX.east;
}

function extractQuartierKeys(stopName) {
  const n = norm(stopName);
  const found = [];
  Object.keys(TANA_QUARTIERS).forEach((key) => {
    if (n.includes(key) || (key.length >= 5 && n.replace(/\s/g, '').includes(key.replace(/\s/g, '')))) {
      found.push({ key, len: key.length });
    }
  });
  found.sort((a, b) => b.len - a.len);
  return found.map((f) => f.key);
}

/**
 * Corrige lat/lng si le nom indique un quartier et la position DB est trop éloignée.
 */
export function correctStopCoordinates(arret) {
  if (!arret?.nom) return arret;

  const quartiers = extractQuartierKeys(arret.nom);
  const primary = quartiers[0];
  if (!primary || !TANA_QUARTIERS[primary]) {
    return arret;
  }

  const [refLat, refLng] = TANA_QUARTIERS[primary];
  const curLat = arret.lat ?? arret.latitude;
  const curLng = arret.lng ?? arret.longitude;

  if (typeof curLat !== 'number' || typeof curLng !== 'number' || Number.isNaN(curLat)) {
    return {
      ...arret,
      lat: refLat,
      lng: refLng,
      latitude: refLat,
      longitude: refLng,
      coords_corrigees: true,
    };
  }

  if (!inBbox(curLat, curLng)) {
    return {
      ...arret,
      lat: refLat,
      lng: refLng,
      latitude: refLat,
      longitude: refLng,
      coords_corrigees: true,
    };
  }

  const delta = distM([curLat, curLng], [refLat, refLng]);
  if (delta >= 800) {
    return {
      ...arret,
      lat: refLat,
      lng: refLng,
      latitude: refLat,
      longitude: refLng,
      coords_corrigees: true,
    };
  }

  if (delta <= 250) {
    return arret;
  }

  // Entre 250m et 800m, on considère que la position est "assez proche"
  // et on évite de la "snapper" au centre du quartier (sinon la trajectoire peut sembler rebrousser).
  return arret;
}

export function correctArretsList(arrets) {
  return (arrets || []).map(correctStopCoordinates);
}
